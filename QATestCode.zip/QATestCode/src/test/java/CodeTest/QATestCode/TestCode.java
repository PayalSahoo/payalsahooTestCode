package CodeTest.QATestCode;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class TestCode {
	
	@Test
	public void QATestCODE() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\PayalSahoo\\eclipse-workspace\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.dbs.com.sg/personal/default.page");
		driver.manage().window().maximize();

		// clicking on the card
		WebElement cards = driver.findElement(By.xpath("//a[text() = 'Cards']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", cards);

		// Click on Credit Cards
		driver.findElement(By.xpath("//a[text() = 'Credit Cards']")).click();

		// Select 2 cards to make comparison and comparison page displayed.

		Actions action = new Actions(driver);
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(9000);
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		driver.findElement(
				By.xpath("//*[@id=\"bodywrapper\"]/div[2]/div/div[1]/div/div/div[1]/div/div[2]/div/label/div[1]/span"))
				.click();
		driver.findElement(
				By.xpath("//*[@id=\"bodywrapper\"]/div[2]/div/div[1]/div/div/div[2]/div/div[2]/div/label/div[1]/span"))
				.click();
		driver.findElement(By.id("cardCompareBtn")).click();
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		System.out.println("Comparision shown successfully");
		driver.quit();
	}
		
}
